# Review sequence

Review the live site in this order:

1. Welcome screen
2. Module 1: Your role and limits
3. Module 2: Starting the call
4. Module 3: Discovery and qualification
5. Module 4: Outcomes and notes
6. Module 5: Shared-Drive workflow
7. Module 6: Products, warranty and quotes
8. Module 7: Follow-up and handover
9. Module 8: Opt-outs and difficult calls
10. Module 9: Full-call simulation
11. Final assessment

Do not approve later modules until the earlier module is correct.
