# AresFit Sales Rep Training

This folder is ready for GitHub Pages.

## Publish
1. Create a new public or private GitHub repository.
2. Upload `index.html` to the repository root.
3. Open **Settings > Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Open the Pages URL GitHub provides.

The course stores learner progress in the browser using local storage.
